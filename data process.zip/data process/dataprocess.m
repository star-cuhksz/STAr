close all;clc;clear
load dataprocess;

temp1=22590+31;
temp2=23510;

figure
plot(dataprocess(temp1:temp2,2));
figure
plot(dataprocess(temp1:temp2,4));
figure
plot(dataprocess(temp1:temp2,6));
figure
plot(dataprocess(temp1:temp2,8));
figure
plot(dataprocess(temp1:temp2,10));
figure
plot(dataprocess(temp1:temp2,12));
figure
plot(dataprocess(temp1:temp2,14));
figure
plot(dataprocess(temp1:temp2,16));

figure
subplot(2,4,1)
plot(dataprocess(temp1:temp2,2));
title('Heading')
subplot(2,4,2)
plot(dataprocess(temp1:temp2,4));
title('Main sail boom angle')
subplot(2,4,3)
plot(dataprocess(temp1:temp2,6));
title('Main sail angle')
subplot(2,4,4)
plot(dataprocess(temp1:temp2,8));
title('Jib sail angle')
subplot(2,4,5)
plot(dataprocess(temp1:temp2,10));
title('Jib sail boom angle')
subplot(2,4,6)
plot(dataprocess(temp1:temp2,12));
title('Voltage/V')
subplot(2,4,7)
plot(dataprocess(temp1:temp2,14));
title('Current/mA')
subplot(2,4,8)
plot(dataprocess(temp1:temp2,16));
title('Wind directrion value')
