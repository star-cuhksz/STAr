NatNet based Maya Plugin (AutoDesk) created by Al Macleod

The GitHub project can be found at,
https://github.com/mocap-ca/mayaMocap/tree/master/mayaMotive

Binaries + some python code,
https://github.com/mocap-ca/mayaMocap/tree/master/BUILDS/mayaMotive